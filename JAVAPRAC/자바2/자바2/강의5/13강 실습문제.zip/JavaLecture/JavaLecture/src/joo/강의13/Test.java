package joo.강의13;

import java.util.List;

public class Test<T> {

	public void add(List<T> list)
	{
		
	}
	

	
	
}
