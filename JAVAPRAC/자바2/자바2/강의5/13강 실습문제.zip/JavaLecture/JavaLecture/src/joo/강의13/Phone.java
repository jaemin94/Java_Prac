package joo.강의13;

public class Phone {

	String Model;
	int serialNumber;

	Phone(String Model, int serialNumber)
	{
		this.Model = Model;
		this.serialNumber = serialNumber;
	}
}
