package joo.강의12;

public class MyException extends Exception{

	
	public MyException(String msg) {
		super(msg);
	}

}
