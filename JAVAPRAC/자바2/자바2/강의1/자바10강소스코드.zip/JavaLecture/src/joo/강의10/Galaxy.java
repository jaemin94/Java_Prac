package joo.강의10;

public class Galaxy extends Phone{

}
