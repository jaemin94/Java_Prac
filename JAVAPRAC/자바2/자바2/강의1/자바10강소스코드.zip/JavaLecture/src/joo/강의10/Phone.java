package joo.강의10;

public abstract class Phone {
	String phoneNumber;
}
