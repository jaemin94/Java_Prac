package joo.강의10;

public class IPhone extends Phone{

}
