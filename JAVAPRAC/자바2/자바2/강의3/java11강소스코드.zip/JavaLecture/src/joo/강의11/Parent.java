package joo.강의11;

public class Parent {
	private int age= 60;
	
	
	public int getAge()
	{
		return this.age;
	}
}
