package joo.강의11;

public class Sofa extends Item{

	
	  public Sofa()
	  {
		  
	  }
	
	  public Sofa(int barcodNumber,String name, int price) 
	  {
		  super(barcodNumber,name, price); 
	  }
	 
	  
	
}
