package joo.강의11;

public class Bicycle extends Item{
	public Bicycle(int barcodNumber,String name, int price) 
	{
		super(barcodNumber,name, price);
	}
}
