package joo.강의11;

public class Child extends Parent{
	
	private int age=20;
	

	public int getAge()
	{
		return this.age;
	}
}
