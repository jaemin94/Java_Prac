package joo.강의11.RPG;

public interface Repairable {

	
	void repaired();
	
}
