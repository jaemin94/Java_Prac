package joo.강의11.RPG;

public class Punch extends Weapon{
	
	
	public Punch(int damage, int durability)
	{
		super( damage,  durability);
	}
}
