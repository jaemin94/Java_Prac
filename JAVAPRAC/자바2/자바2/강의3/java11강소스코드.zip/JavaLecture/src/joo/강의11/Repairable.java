package joo.강의11;

public interface Repairable {
	void repaired();
}
