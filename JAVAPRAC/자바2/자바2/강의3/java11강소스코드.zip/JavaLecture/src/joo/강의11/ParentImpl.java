package joo.강의11;

public interface ParentImpl {

	
	void a();
	void b();
	void c();
}
