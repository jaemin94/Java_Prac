package joo.강의11;

public class Zealot extends Unit{

	
	@Override
	public void attack(Unit target) {
		
		
	}
}
