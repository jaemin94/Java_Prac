package joo.강의14;

public class People {
	
	public enum HOBBY{SOCCER,BASEBALL,COOK,RUNNING;}
	
	public HOBBY hobby;

}
